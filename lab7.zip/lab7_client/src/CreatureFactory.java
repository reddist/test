import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.List;

/**
 * Класс, предназначенный для создания объектов Creature по их текстовому описанию.
 */
public class CreatureFactory {
    /**
     * Значения полей объекта.
     */
    private List<String> fields;
    /**
     * Переменная хранит результат создания объекта.
     * @see CreatureFactory#getValue() "геттер"
     */
    private Creature value = null;
    /**
     * Переменная хранит описание объекта.
     * @see CreatureFactory#getDescription() "геттер"
     */
    private String description;
    /**
     * Переменная-флаг, показывающая, правильного ли формата поступающее описание объекта.
     * @see CreatureFactory#isCheckFormat() "геттер"
     */
    private boolean checkFormat = true;
    /**
     * Переменная хранит название класса созданного объекта.
     * @see CreatureFactory#getCreatedClass() "геттер"
     */
    private String createdClass;

    /**
     * Конструктор, принимающий описание объекта в виде строки в формате csv или json (без границ объекта '{' и '}'). При выполнении создаёт соответствующий описанию объект в поле value.
     * @param description описание объекта
     * @param format переменная, обозначающая формат объекта. False - csv, True - json.
     */
    public CreatureFactory(String description, boolean format){
        if(!format)
            this.description = description;
        else
            this.description = parseJsonToCSVDescription(description);
        if(checkFormat) {
            getFields();
            create();
        }
    }

    /**
     * Метод "достаёт" значения полей объекта путём сплита по запятым. Предварительно убирает знаки пробелов и табуляций из строки с помощью метода String.replaceAll(String, String).
     * @see String#split(String)
     * @see String#replaceAll(String, String)
     */
    private void getFields() {
        fields = Arrays.asList(description.replaceAll("\\s+","").split(","));
    }

    /**
     * Метод является "геттером" для поля value.
     * @see CreatureFactory#value
     * @return значение поля value.
     */
    public Creature getValue() {
        return value;
    }

    /**
     * Общий метод для создания объекта. Внутри вызываются более конкретизированные методы.
     * @see CreatureFactory#createHatifnutt()
     * @see CreatureFactory#createHemul()
     * @see CreatureFactory#createMoomin() ()
     */
    private void create() {
        if(fields.size() > 0){
            String type = fields.get(0);
            try {
                switch (type) {
                    case "Hemul":
                        createHemul();
                        break;
                    case "Moomin":
                        createMoomin();
                        break;
                    case "Hatifnutt":
                        createHatifnutt();
                        break;
                    default: {
                        checkFormat = false;
                        System.out.println("Неверные данные. (Неверный тип)");
                    }
                    break;
                }
            } catch(IndexOutOfBoundsException e){
                checkFormat = false;
                System.out.println("Неверные данные в файле. (Нехватка полей у объекта)");
            }
        } else {
            checkFormat = false;
            System.out.println("Неверные данные в файле. (Отсутствие полей у объекта)");
        }
    }

    /**
     * Метод для создания объектов типа Hemul.
     */
    private void createHemul(){
        createdClass = "Hemul";
        Sex sex = null;              // проверка Пола, т.к. все элементы fields - строки, а нужно как-то получить Sex
        switch(fields.get(1)){
            case "MALE": sex = Sex.MALE; break;
            case "FEMALE": sex = Sex.FEMALE; break;
            case "AGAMIC": sex = Sex.AGAMIC; break;
            default : {
                checkFormat = false;
                System.out.println("Неверные данные. (Неверное значение пола)");
                return;
            }
        }
        Vocation vocation = null;       // проверка vocation, т.к. все элементы fields - строки, а нужно как-то получить Vocation
        switch(fields.get(3)){
            case "CollectThings" : vocation = new CollectThings(); break;
            case "CollectRareFlowers" : vocation = new CollectRareFlowers(); break;
            case "Ski" : vocation = new Ski(); break;
            default : {
                checkFormat = false;
                System.out.println("Неверные данные. (Неверное значение призвания)");
                return;
            }
        }
        try {
            if (checkFormat) {
                int height = Integer.parseInt(fields.get(4));
                int x = Integer.parseInt(fields.get(5));
                int y = Integer.parseInt(fields.get(6));
                LocalDateTime date = Creature.parseDate(fields.get(7));
                value = new Hemul(sex, fields.get(2), vocation, height, x, y, date);
            }
        } catch (NumberFormatException e) {
            checkFormat = false;
            System.out.println("Неверные данные. (Неверное значение времени вызова, или энергии, или высоты, или позиции)");
        } catch (DateTimeParseException e) {
            checkFormat = false;
            System.out.println("Неверные данные. (Неверное значение даты)");

        }
        // private Hemul(Sex sex, String name, Vocation v)
        // Hemul, <sex (Sex of the object) >, <name (Name of the object) >, <vocation>
        //   0             1                                2                   3
    }

    /**
     * Метод для создания объектов типа Moomin.
     */
    private void createMoomin(){
        createdClass = "Moomin";
        Sex sex = null;              // проверка Пола, т.к. все элементы fields - строки, а нужно как-то получить Sex
        switch(fields.get(2)){
            case "FEMALE": sex = Sex.FEMALE; break;
            case "MALE": sex = Sex.MALE; break;
            case "AGAMIC": sex = Sex.AGAMIC; break;
            default : {
                checkFormat = false;
                System.out.println("Неверные данные в файле. (Неверное значение пола)");
                return;
            }
        }
        try {
            if (checkFormat) {
                long lastCall = Long.parseLong(fields.get(3));
                long lastEnd = Long.parseLong(fields.get(4));
                double energy = Double.parseDouble(fields.get(5));
                int height = Integer.parseInt(fields.get(6));
                int x = Integer.parseInt(fields.get(7));
                int y = Integer.parseInt(fields.get(8));
                LocalDateTime date = Creature.parseDate(fields.get(9));
                value = new Moomin(sex, fields.get(1), lastCall, lastEnd, energy, height, x, y, date);
            }
        } catch (NumberFormatException e) {
            checkFormat = false;
            //e.printStackTrace();
            System.out.println("Неверные данные в файле. (Неверное значение времени вызова, или энергии, или высоты, или позиции)");
        } catch (DateTimeParseException e) {
            checkFormat = false;
            System.out.println("Неверные данные в файле. (Неверное значение даты)");
        }
        // public Moomin(Sex sex, String name, long lastCall, long lastEnd, double energy)
        // Moomin, <name (Name of the object) >, <sex (Sex of the object) >, <lastCall>, <lastEnd>, <energy>
        //   0             1                                2                   3           4          5
    }

    /**
     * Метод для создания объектов типа Hatifnutt.
     */
    private void createHatifnutt(){
        createdClass = "Hatifnutt";
        try {
            if (checkFormat) {
                int height = Integer.parseInt(fields.get(2));
                int x = Integer.parseInt(fields.get(3));
                int y = Integer.parseInt(fields.get(4));
                LocalDateTime date = Creature.parseDate(fields.get(5));
                value = new Hatifnutt(fields.get(1), height, x, y, date);
            } else {
                System.out.println("Неверные данные в файле.");
            }
        } catch (NumberFormatException e) {
            checkFormat = false;
            System.out.println("Неверные данные в файле. (Неверное значение высоты или позиции)");
        } catch (DateTimeParseException e) {
            checkFormat = false;
            System.out.println("Неверные данные в файле. (Неверное значение даты)");
        }
        // public Hatifnutt(String name)
        // Hatifnutt, <name (Name of the object) >
        //     0               1                                   (номер в fields)
    }

    /**
     * Преобразовывает объект в json-формате в csv-формат, удобный для сохранения и последующей работы.
     * @param json объект json (без фигурных скобок, обозначающих границы самого объекта).
     * @return  Возвращает объект в csv-формате.
     */
    private String parseJsonToCSVDescription(String json){
        json = json.replaceAll("\"", "");
        String csvDescription = "";
        List<String> fields = Arrays.asList(json.split(","));
        if(fields.size() == 6){
            int i = 0;
            //0 - class, 1 - name, 2 - height, 3 - x, 4 - y, 5 - date
            boolean checks[] = new boolean[6];
            String[] csvFields = new String[6];
            for(List<String> pair; i < 6; i++){
                pair = Arrays.asList(fields.get(i).split(":"));
                if(pair.get(0).equals("Class")) checks[0] = true;
                if(pair.get(0).equals("Name")) checks[1] = true;
                if(pair.get(0).equals("Height")) checks[2] = true;
                if(pair.get(0).equals("X")) checks[3] = true;
                if(pair.get(0).equals("Y")) checks[4] = true;
                if(pair.get(0).equals("Date")) checks[5] = true;
            }
            boolean totalCheck = true;
            for(boolean check : checks) {
                totalCheck &= check;
                if(!totalCheck) break;
            }
            if(totalCheck){
                this.checkFormat = true;
                i = 0;
                for(List<String> pair; i < 6; i++){
                    pair = Arrays.asList(fields.get(i).split(":"));
                    if(pair.get(0).equals("Class")) csvFields[0] = pair.get(1);
                    if(pair.get(0).equals("Name")) csvFields[1] = pair.get(1);
                    if(pair.get(0).equals("Height")) csvFields[2] = pair.get(1);
                    if(pair.get(0).equals("X")) csvFields[3] = pair.get(1);
                    if(pair.get(0).equals("Y")) csvFields[4] = pair.get(1);
                    if(pair.get(0).equals("Date")){
                        String date = pair.get(1);
                        for(int j = 2; j < pair.size(); j++)
                            date += ':' + pair.get(j);
                        csvFields[5] = date;
                    }
                }
                for(i = 0; i < 5; i++)
                    csvDescription += csvFields[i] + ", ";
                csvDescription += csvFields[5];
            } else
                this.checkFormat = false;
            return csvDescription;
        }
        if(fields.size() == 8){
            int i = 0;
            //0 - class, 1 - sex, 2 - name, 3 - vocation, 4 - height, 5 - x, 6 - y, 7 - date
            boolean checks[] = new boolean[8];
            String[] csvFields = new String[8];
            for(List<String> pair; i < 8; i++){
                pair = Arrays.asList(fields.get(i).split(":"));
                if(pair.get(0).equals("Class")) checks[0] = true;
                if(pair.get(0).equals("Sex")) checks[1] = true;
                if(pair.get(0).equals("Name")) checks[2] = true;
                if(pair.get(0).equals("Vocation")) checks[3] = true;
                if(pair.get(0).equals("Height")) checks[4] = true;
                if(pair.get(0).equals("X")) checks[5] = true;
                if(pair.get(0).equals("Y")) checks[6] = true;
                if(pair.get(0).equals("Date")) checks[7] = true;
            }
            boolean totalCheck = true;
            for(boolean check : checks) {
                totalCheck &= check;
                if(!totalCheck) break;
            }
            if(totalCheck){
                this.checkFormat = true;
                i = 0;
                for(List<String> pair; i < 8; i++){
                    pair = Arrays.asList(fields.get(i).split(":"));
                    if(pair.get(0).equals("Class")) csvFields[0] = pair.get(1);
                    if(pair.get(0).equals("Sex")) csvFields[1] = pair.get(1);
                    if(pair.get(0).equals("Name")) csvFields[2] = pair.get(1);
                    if(pair.get(0).equals("Vocation")) csvFields[3] = pair.get(1);
                    if(pair.get(0).equals("Height")) csvFields[4] = pair.get(1);
                    if(pair.get(0).equals("X")) csvFields[5] = pair.get(1);
                    if(pair.get(0).equals("Y")) csvFields[6] = pair.get(1);
                    if(pair.get(0).equals("Date")){
                        String date = pair.get(1);
                        for(int j = 2; j < pair.size(); j++)
                            date += ':' + pair.get(j);
                        csvFields[7] = date;
                    }
                }
                for(i = 0; i < 7; i++)
                    csvDescription += csvFields[i] + ", ";
                csvDescription += csvFields[7];
            } else
                this.checkFormat = false;
            return csvDescription;
        }
        if(fields.size() == 10){
            int i = 0;
            // 0 - Class, 1 - Name, 2 - Sex, 3 - LastCall, 4 - LastEnd, 5 - Energy, 6 - height, 7 - X, 8 - Y, 9 - date
            boolean[] checks = new boolean[10];
            String[] csvFields = new String[10];
            for(List<String> pair; i < 10; i++){
                pair = Arrays.asList(fields.get(i).split(":"));
                if(pair.get(0).equals("Class")) checks[0] = true;
                if(pair.get(0).equals("Name")) checks[1] = true;
                if(pair.get(0).equals("Sex")) checks[2] = true;
                if(pair.get(0).equals("LastCall")) checks[3] = true;
                if(pair.get(0).equals("LastEnd")) checks[4] = true;
                if(pair.get(0).equals("Energy")) checks[5] = true;
                if(pair.get(0).equals("Height")) checks[6] = true;
                if(pair.get(0).equals("X")) checks[7] = true;
                if(pair.get(0).equals("Y")) checks[8] = true;
                if(pair.get(0).equals("Date")) checks[9] = true;
            }
            boolean totalCheck = true;
            for(boolean check : checks) {
                totalCheck &= check;
                if(!totalCheck) break;
            }
            if(totalCheck){
                this.checkFormat = true;
                i = 0;
                for(List<String> pair; i < 10; i++){
                    pair = Arrays.asList(fields.get(i).split(":"));
                    if(pair.get(0).equals("Class")) csvFields[0] = pair.get(1);
                    if(pair.get(0).equals("Name")) csvFields[1] = pair.get(1);
                    if(pair.get(0).equals("Sex")) csvFields[2] = pair.get(1);
                    if(pair.get(0).equals("LastCall")) csvFields[3] = pair.get(1);
                    if(pair.get(0).equals("LastEnd")) csvFields[4] = pair.get(1);
                    if(pair.get(0).equals("Energy")) csvFields[5] = pair.get(1);
                    if(pair.get(0).equals("Height")) csvFields[6] = pair.get(1);
                    if(pair.get(0).equals("X")) csvFields[7] = pair.get(1);
                    if(pair.get(0).equals("Y")) csvFields[8] = pair.get(1);
                    if(pair.get(0).equals("Date")){
                        String date = pair.get(1);
                        for(int j = 2; j < pair.size(); j++)
                            date += ':' + pair.get(j);
                        csvFields[9] = date;
                    }
                }
                for(i = 0; i < 9; i++)
                    csvDescription += csvFields[i] + ", ";
                csvDescription += csvFields[9];
            } else
                this.checkFormat = false;
            return csvDescription;
        }
        return csvDescription;
    }

    /**
     * Метод является "геттером" для поля checkFormat.
     * @see CreatureFactory#checkFormat
     * @return значение поля checkFormat.
     */
    public boolean isCheckFormat() {
        return checkFormat;
    }

    /**
     * Метод является "геттером" для поля description.
     * @see CreatureFactory#description
     * @return значение поля description.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Метод является "геттером" для поля createdClass.
     * @see CreatureFactory#createdClass
     * @return значение поля createdClass.
     */
    public String getCreatedClass() {
        return createdClass;
    }
}
