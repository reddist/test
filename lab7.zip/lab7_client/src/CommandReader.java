import java.io.*;
import java.util.Arrays;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;

/**
 *  Класс, предназначенный для считывания и интерпретации команд.
 */
public class CommandReader {
    /**
     * Переменная, через которую происходит первоначальное считывание данных из файла (Нужна исполнителю для команд CommandExecutor.save(MyReader) и CommandExecutor.exit(MyReader)).
     * @see CommandExecutor#exit(MyReader)
     * @see CommandExecutor#save(MyReader)
     */
    MyReader reader;

    ObjectOutputStream streamToServer;

    /**
     * Конструктор для создания объекта с определённым "считывателем" из файла и исполнителем команд.
     * @param reader "считыватель" из первоначального файла.
     * @see MyReader
     * @see CommandExecutor
     */
    public CommandReader(MyReader reader, ObjectOutputStream streamToServer) {
        this.reader = reader;
        this.streamToServer = streamToServer;
    }

    /**
     * Метод, выполняющий считывание и интерпретацию команд, также выполняющий проверку на соответствие введённых команд Формату команд и Формату json-объектов.
     */
    public void readCommands(Scanner consoleIn) throws IOException {
        {
            String consoleCommand = consoleIn.nextLine();                                  // Считывание первой строчки
            while((charCounter(consoleCommand, '{') != charCounter(consoleCommand, '}'))) {     // Ввод построчно до конца объекта json, если в
                System.out.print("\t");                                                                        // первой строке была открывающая скобка '{'
                consoleCommand += consoleIn.nextLine();
            }
            String newCommand = consoleCommand.replaceAll("\\s+", "");      // Удаление всех пробелов, табуляций, знаков переносов строки
            if(newCommand.matches("[a-zIA_]+") ||    // Проверка соответствия введённой команды: - командам без объекта
                    newCommand.matches("([a-z_]+)(\\{[a-zA-Z0-9/_\\.\\-\\:\\\\]+)\\}") ||       // Проверка на команду import
                    newCommand.matches("[a-z_]+(\\{(\"[\\w]+\":((\"[\\w:\\-]+\",)|(-?[0-9]+,))){5}(\"[\\w]+\":((\"[\\w:\\-]+\")|(-?[0-9]+)))\\})") || // - командам с объектом Hatifnutt
                    newCommand.matches("[a-z_]+(\\{(\"[\\w]+\":((\"[\\w:\\-]+\",)|(-?[0-9]+,))){7}(\"[\\w]+\":((\"[\\w:\\-]+\")|(-?[0-9]+)))\\})") ||               // - командам с объектом Hemul
                    newCommand.matches("[a-z_]+(\\{((\"[\\w]+\":)((\"[\\w:\\-]+\",)|(-?[0-9]+(\\.[0-9]+)?,))){9}((\"[\\w]+\":)((\"[\\w:\\-]+\")|(-?[0-9]+(\\.[0-9]+)?)))\\})")) {               // - командам с объектом Moomin
                String command = "";
                int i = 0;
                for (char c; i < newCommand.length() && (newCommand.charAt(i) != '{'); i++) {
                    c = newCommand.charAt(i);
                    command += c;
                }
                if (newCommand.matches("([a-z_]+)(\\{[a-zA-Z0-9/_\\.\\-\\:\\\\]+)\\}")) {
                    String returned = "";
                    String address = newCommand.substring(i + 1, newCommand.length() - 1);
                    boolean fileNotFound = false;
                    File importFrom = new File(address);
                    if(!importFrom.exists())
                        fileNotFound = true;
                    if (!fileNotFound) {
                        streamToServer.writeUTF(command);
                        try {
                            InputStreamReader in = new InputStreamReader(new FileInputStream(address), "UTF-8");
                            try {
                                System.out.format("+ Extraction from %s\n", address);
                                int bufferSize = 130000;
                                char[] buffer = new char[bufferSize];
                                int readSize = in.read(buffer, 0, buffer.length);
                                if (readSize < bufferSize) {
                                    buffer = Arrays.copyOf(buffer, readSize);    // копирование в buffer, если количество считанных символов
                                }                                                 // меньше 1024, т.к. иначе лишние переносы строк
                                streamToServer.writeUTF(new String(buffer));
                                streamToServer.flush();
                            } catch (UnsupportedEncodingException e) {
                                returned += "Кодировка не поддерживается.\n";
                                streamToServer.writeUTF("");
                                streamToServer.flush();
                            } catch (NegativeArraySizeException e) {
                                returned += "Нет данных в файле.\n";
                                streamToServer.writeUTF("");
                                streamToServer.flush();
                            } catch (SecurityException e) {
                                returned += "Файл недоступен для чтения.\n";
                                streamToServer.writeUTF("");
                                streamToServer.flush();
                            }
                        } catch (FileNotFoundException e) {
                            returned += "Файл не найден.\n";
                            streamToServer.writeUTF("");
                            streamToServer.flush();
                        }
                    } else {
                        returned += "Файла не существует.\n";
                        streamToServer.writeUTF("");
                        streamToServer.flush();
                    }
                    System.out.println(returned);
                } else {
                    if (newCommand.matches("[a-zIA_]+")) {
                        if(newCommand.equals("import")){
                            streamToServer.writeUTF("wrong");
                            streamToServer.flush();
                        }
                        streamToServer.writeUTF(command);
                        streamToServer.flush();
                    } else {
                        CreatureFactory creatureFactory = new CreatureFactory(newCommand.substring(i + 1, newCommand.length() - 1), true);
                        if (creatureFactory.isCheckFormat()) {
                            streamToServer.writeUTF(command);
                            streamToServer.flush();
                            streamToServer.writeObject(creatureFactory.getValue());
                            streamToServer.flush();
                        } else {
                            System.out.println("Неверные поля в объекте.");
                            streamToServer.writeUTF("wrong");
                            streamToServer.flush();
                        }
                    }
                }
            } else {
                System.out.println("Неправильный формат ввода!!!.");
                streamToServer.writeUTF("wrong");
                streamToServer.flush();
            }
        }
    }


    /**
     * Считает количество вхождений символа в строке. Работает на основе замены во всей строке символа методом String.replaceAll(String, String) и нахождения разности длины с начальной строкой.
     * @param string входная строка
     * @param character символ для подсчёта
     * @return Количество вхождений символа в строку
     * @see String#replaceAll(String, String)
     */
    public static int charCounter(String string, Character character){
        String regex = "\\ " + character;
        regex = regex.replaceAll("\\s+", "");
        return string.length() - string.replaceAll(regex, "").length();
    }

}
