import java.io.Serializable;

public class HatifnuttAction implements CreatureAction, Serializable {
	public void walk(){
		System.out.println(" goes. In the summer it will bow to the barometer.");
	}
	public void eat(Thing th){
		System.out.println(" tries to eat " + th.getName().toLowerCase() + ". Hatifnutts can't eat.");
	}
	public void communicate(Creature cr, String phrase){
		System.out.println(" shows respect and bows to " + cr.getName() + ".");
	}
	public String info(){
		return "Hatifnutt action";
	}
}