import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.Comparator;
import java.util.Objects;

public abstract class Creature implements Comparable<Creature>, Comparator<Creature>, Serializable {
	private CreatureAction creatureAction;
	private String name;
	private Sex sex;
	private int height;
	private int x;
	private int y;
	private LocalDateTime initializationDate;
	private String owner;


	public Creature(){
		this.setName("Creature");
		this.setInitializationDate(LocalDateTime.now());
	}

	public String getName(){
		return this.name;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public CreatureAction getCreatureAction(){
		return this.creatureAction;
	}

	public void setCreatureAction(CreatureAction crAct){
		this.creatureAction = crAct;
	}

	public Sex getSex(){
		return this.sex;
	}

	public void setSex(Sex s){
		this.sex = s;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public void walk(){
		System.out.print(this.getName());
		this.getCreatureAction().walk();
	}
	public void eat(Thing th){
		System.out.print(this.getName());
		this.getCreatureAction().eat(th);
	}
	public void communicate(Creature cr, String phrase){
		System.out.print(this.getName());
		this.getCreatureAction().communicate(cr, phrase);
		// cr.communicate(this);
	}

	public abstract String csvDescription();

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Creature)) return false;
		Creature creature = (Creature) o;
		return this.getHeight() == creature.getHeight() &&
				this.getX() == creature.getX() &&
				this.getY() == creature.getY() &&
				this.getInitializationDate().equals(creature.getInitializationDate()) &&
				this.getCreatureAction().info().equals(creature.getCreatureAction().info()) &&
				this.getName().equals(creature.getName()) &&
				this.getSex().toString().equals(creature.getSex());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getName(), getSex(), getHeight(), getX(), getY(), getInitializationDate());
	}

	@Override
	public String toString() {
		return "Creature{" +
				"creatureAction = " + creatureAction.info() +
				", name = \'" + name + '\'' +
				", sex = " + sex +
				", height = " + height +
				", position = ( " + x + " ; " + y + " )" +
				", initalizationDate = " + this.getInitializationDate() +
				'}';
	}

	public abstract String shortToString();

	public abstract String getClassName();

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public LocalDateTime getInitializationDate() {
		return initializationDate;
	}

	public void setInitializationDate(LocalDateTime initializationDate) {
		this.initializationDate = initializationDate;
	}

	public static LocalDateTime parseDate(String date) throws DateTimeParseException{
		return LocalDateTime.parse(date);
	}

	public int compareTo(Creature creature){
		return this.getName().length() - creature.getName().length();
	}

	public int compare(Creature creature1, Creature creature2){
		return creature1.compareTo(creature2);
	}
}