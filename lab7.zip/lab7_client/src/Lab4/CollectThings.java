import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;
import java.util.Objects;

public class CollectThings implements Vocation, Serializable {
	private int amountOfThings;
	private List<Thing> things;

	public CollectThings(){
		this.setAmount(0);
		things = new ArrayList<Thing>();
	}
	
	public void do_(Object o) throws IncorrectVocationParameter{
		if(!(o instanceof Thing)) throw new IncorrectVocationParameter(this.getCorrectParameter());
		//Thing th = new Thing("Some thing " + (this.getAmount() + 1), Condition.NORMAL);
		this.addThing((Thing) o);
	}

	private void addThing(Thing th){
		try{
			System.out.println("adds " + th.getName() + ".");
			this.things.add(th);
		}catch(NullPointerException e){
			System.out.println("Ooooops... in trying to add new \"Some Thing\"");
		} 
        this.amountOfThings++;
	}

	public String getCurrentVocation(){
		return "CollectThings";
	}

	public String getCorrectParameter(){
		return "Thing";
	}

	public String info(){
		if(this.getAmount() == 0){
			return "Amount of things is 0.";
		}else{
			String s = "Amount of things is " + this.getAmount() + ". Things are: ";
			String s1 = "";
			for (Thing thing : this.things){
				s1 += thing.getName() + ", ";
			}
			for (int i = 0; i < s1.length() - 2; i++)
				s += s1.charAt(i);
			s += ".";
			return s;
		}
	}

	public String toString(){
		return getCurrentVocation();
	}
	public int getAmount(){
		return this.amountOfThings;
	}
	public void setAmount(int a){
		this.amountOfThings = a;
	}
	public List<Thing> getThings(){
		return this.things;
	}
	public void addAmount(int a){
		this.amountOfThings += a;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof CollectThings)) return false;
		CollectThings that = (CollectThings) o;
		return amountOfThings == that.amountOfThings &&
				Objects.equals(things, that.things);
	}

	@Override
	public int hashCode() {
		return Objects.hash(amountOfThings, things);
	}
}