import java.io.Serializable;

public enum TemperatureCondition implements Serializable {
    COLD,
    NORMAL,
    WARM,
    BURNED;

    @Override
    public String toString(){
        String st = "";
        switch(this){
            case COLD: st = "Cold";
                break;
            case NORMAL: st = "Normal";
                break;
            case WARM: st = "Warm";
                break;
            case BURNED: st = "Burned";
                break;
        }
        return st;
    }
}
