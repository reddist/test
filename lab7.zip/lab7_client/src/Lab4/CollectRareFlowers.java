import java.io.Serializable;

public class CollectRareFlowers extends CollectThings implements Serializable {

	@Override
	public void do_(Object o) throws IncorrectVocationParameter{
		if(!(o instanceof RareFlower)) throw new IncorrectVocationParameter(this.getCorrectParameter());
		//RareFlower f = new RareFlower();
		this.addFlower((RareFlower) o);
	}

	private void addFlower(RareFlower f) {
		try {
			System.out.print("adds " + f.getName() + ". ");
			this.getThings().add(f);
		} catch (NullPointerException e) {
			System.out.println("Ooooops...");
		}
		this.addAmount(1);
		this.mutter();
	}

	public String getCurrentVocation() {
		return "CollectRareFlowers";
	}

	public String getCorrectParameter(){
		return "RareFlower";
	}

	public String info() {
		if (this.getAmount() == 0) {
			return "Amount of rare flowers is 0.";
		} else {
			String s = "Amount of rare flowers is " + this.getAmount() + ". Flowers are: ";
			String s1 = "";
			for (Thing thing : this.getThings()) {
				s1 += thing.getName() + ", ";
			}
			for (int i = 0; i < s1.length() - 2; i++)
				s += s1.charAt(i);
			s += ".";
			return s;
		}
	}

	private void mutter() {
		System.out.println("Бормочет: \"Это будет номер " + this.getAmount() + " в моем гербарии\".");
	}
}