import java.io.Serializable;

public class HemulAction implements CreatureAction, Serializable {
	public void walk(){
		System.out.print(" goes to do ");
	}
	public void eat(Thing th){
		System.out.print(" is going to eat " + th.getName().toLowerCase() + ". ");
		th.breaks();
	}
	public void communicate(Creature cr, String phrase){
		System.out.println(" says \"" + phrase + "\" to " + cr.getName() + ".");
	}
	public String info(){
		return "Hemul action";
	}
}