import java.io.Serializable;
import static java.lang.Math.*;

public class SlatPair extends Thing implements Serializable{

    private Slat rightSlat;
    private Slat leftSlat;

    public SlatPair(String name){
        super(name);
        this.changeLeftSlat(new Slat("Left slat"));
        this.changeRightSlat(new Slat("Right slat"));
    }

    class Slat extends Thing implements Serializable {
        public Slat(){
            this("Slat", Condition.NORMAL);
        }
        public Slat(String name) { this(name, Condition.NORMAL); }
        public Slat(String s, Condition c) {
            super(s, c);
        }

        @Override
        public String toString() {
            return "Slat{" +
                    "nameOfThing = '" + this.getName() + '\'' +
                    ", condition = " + this.getCondition() +
                    '}';
        }
    }

    public SlatPair(String name, String ls, String rs){
        this(name, ls, Condition.NORMAL, rs, Condition.NORMAL);
    }

    public SlatPair(String name, String ls, Condition lsCond, String rs, Condition rsCond){
        super(name);
        Slat lslat = new Slat(ls, lsCond);
        Slat rslat = new Slat(rs, rsCond);
        this.changeSlat(lslat, "left");
        this.changeSlat(rslat, "right");
        if(lslat.getCondition().equals(Condition.NORMAL) && rslat.getCondition().equals(Condition.NORMAL))
            this.setCondition(Condition.NORMAL);
        else
            this.setCondition(Condition.BROKEN);
    }

    public void changeSlat(String s, Condition c, String pos) {
        this.changeSlat(new Slat(s, c), pos);
    }

    private void changeSlat(Slat s, String pos) {
        switch (pos) {
            case "left": this.changeLeftSlat(s); break;
            case "right": this.changeRightSlat(s); break;
        }
    }

    private void changeRightSlat(Slat s){
        rightSlat = s;
    }

    private void changeLeftSlat(Slat s){
        leftSlat = s;
    }

    public Slat getLeftSlat() {
        return leftSlat;
    }

    public Slat getRightSlat() {
        return rightSlat;
    }

    @Override
    public void breaks(){
        double chance = abs(random());
        double breakChance = 0.4;
        if(chance < breakChance) {
            leftSlat.breaks();
            this.setCondition(Condition.BROKEN);
        }
        chance = abs(random());
        if(chance < breakChance) {
            rightSlat.breaks();
            this.setCondition(Condition.BROKEN);
        }
    }

    public void repair(){
        double chance = abs(random());
        if(chance < 0.6) {
            leftSlat.setCondition(Condition.NORMAL);
        }
        chance = abs(random());
        if(chance < 0.6) {
            rightSlat.setCondition(Condition.NORMAL);
        }
        if(leftSlat.getCondition().equals(Condition.NORMAL) && rightSlat.getCondition().equals(Condition.NORMAL))
            this.setCondition(Condition.NORMAL);
    }
}
