import java.io.Serializable;

public class MoominAction extends HemulAction implements Serializable{

    private double energy;          // energy in joules
    private long time;            // time in milliseconds
    private static final MoominAction jump;
    private static final MoominAction maneuver;
    private static final MoominAction makeHearth;
    private static final MoominAction heating;

    public MoominAction(){
        this(0, 0);
    }

    private MoominAction(double energy, double time){
        this.setEnergy(energy);
        this.time = (long)time;
    }

    public void walk() {
        System.out.println(" goes.");
    }

    public String info() {
        return "Moomin Action";
    }

    public void do_(Object o) throws NotFoodException {
        System.out.println(" exists.");
    }

    private void setEnergy(double p){
        energy = p;
    }

    public double getEnergy(){
        return energy;
    }
    public long getTime(){
        return this.time;
    }

    public static MoominAction getJump() {
        return MoominAction.jump;
    }

    public static MoominAction getManeuver() {
        return maneuver;
    }

    public static MoominAction getMakeHearth() {
        return makeHearth;
    }

    public static MoominAction getHeating() {
        return heating;
    }

    static{
        jump = new MoominAction(50.5, 1500.0){
            @Override
            public String info() {
                return "jumping";
            }

            public void do_(Object o){
                System.out.println(" jumps with a rope.");
            }
        };
        maneuver = new MoominAction(70.36, 5000.0){
            @Override
            public String info() {
                return "maneuvering";
            }

            public void do_(Object o){
                System.out.println(" is maneuvering through the shallows to get to the coast.");
            }
        };
        makeHearth = new MoominAction(265.87, 10000.0){
            @Override
            public String info() {
                return "making a hearth";
            }

            public void do_(Object o){
                System.out.println(" is making a hearth.");
            }
        };
        heating = new MoominAction(40.54, 4000.0){
            @Override
            public String info() {
                return "heating";
            }

            public void do_(Object o) throws NotFoodException{
                String message = " is heating " + o.toString() + ". It's temperature condition will be ";
                if (!(o instanceof Food))
                    throw new NotFoodException(" is unable to heat " + o);
                else {
                    ((Food) o).getHeated();
                    message += ((Food) o).getTemperatureCondition() + ".";
                    System.out.println(message);
                }
            }
        };
    }
}
