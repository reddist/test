import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

public class Moomin extends Creature implements Serializable {

    private long lastCall;
    private long lastEnd;
    private double energy;
    private final double MAX_ENERGY = 2000.0;

    public Moomin(){
        this(Sex.MALE, "Moomin");
    }

    public Moomin(Sex sex, String name, long lastCall, long lastEnd, double energy, int height, int posX, int posY, LocalDateTime date){
        this(sex, name);
        this.lastCall = lastCall;
        this.lastEnd = lastEnd;
        this.energy = energy;
        this.setHeight(height);
        this.setX(posX);
        this.setY(posY);
        this.setInitializationDate(date);
    }

    public Moomin(Sex sex, String name){
        this.setCreatureAction(new MoominAction());
        this.setName(name);
        this.setSex(sex);
        this.setHeight(100);
        this.setX(30);
        this.setY(30);
        this.setInitializationDate(LocalDateTime.parse("2018-10-22T20:15:56"));
        lastCall = 0;
        energy = 100.0;
        lastEnd = System.currentTimeMillis();
    }

    public void do_(Object o){
            //System.out.println(System.currentTimeMillis());
            restFull();
            if(((MoominAction)this.getCreatureAction()).getEnergy() < energy){
                try {
                    System.out.print(this.getName());

                    ((MoominAction) this.getCreatureAction()).do_(o);
                    lastCall = System.currentTimeMillis();
                    System.out.println("energy -" + ((MoominAction)this.getCreatureAction()).getEnergy());
                    energy -= ((MoominAction)this.getCreatureAction()).getEnergy();
                    //System.out.println(energy);
                    int i = 0;
                    System.out.println("Process time: " + ((MoominAction)this.getCreatureAction()).getTime() + " milliseconds");
                    while((double)(System.currentTimeMillis() - lastCall) < ((MoominAction)this.getCreatureAction()).getTime() + 50){
                        i++;
                    }
                    lastEnd = System.currentTimeMillis();
                } catch (NotFoodException e) {
                    System.out.println(e.getMessage());
                }
            }else{
                System.out.println(this.getName() + " hasn't enough energy for " +
                        this.getCreatureAction().info() + ". Needs " + ((MoominAction)this.getCreatureAction()).getEnergy() + " kilo-joules. Energy is " + energy);
            }
        System.out.println();
    }

    public long getLastCall() {
        return lastCall;
    }

    public long getLastEnd() {
        return lastEnd;
    }

    public double getEnergy() {
        rest();
        return energy;
    }

    public void rest() {
        energy += ((double) (System.currentTimeMillis() - lastEnd)) / 10.0D;
        lastEnd = System.currentTimeMillis();
        energy = Math.min(energy, MAX_ENERGY);
    }

    public void restFull(){
        System.out.println("Energy is " + energy + ". Rest starts...");
        //System.out.println(System.currentTimeMillis());
        System.out.println("energy +" + ((double)(System.currentTimeMillis() - lastEnd)) / 10.0D);
        rest();
        System.out.println("Energy is " + energy);
    }

    public String csvDescription(){
        return "Moomin, " + this.getName() + ", " + this.getSex().toString().toUpperCase()
                + ", " + lastCall + ", " + lastEnd + ", " + energy + ", " + this.getHeight()
                + ", " + this.getX() + ", " + this.getY() + ", " + this.getInitializationDate()
                + ", " + this.getOwner();
    }

    public void do_nothing(long sec){
        long sec1 = sec * 1000;
        long z = System.currentTimeMillis();
        while(System.currentTimeMillis() - z < sec1){}
        System.out.println(this.getName() + " did nothing for " + sec + " seconds.");
    }

    @Override
    public String toString() {
        return "Moomin{" +
                "creatureAction = " + this.getCreatureAction().info() +
                ", name = \'" + this.getName() + '\'' +
                ", sex = " + this.getSex() +
                ", lastCall = " + lastCall +
                ", lastEnd = " + lastEnd +
                ", energy = " + energy +
                ", height = " + this.getHeight() +
                ", position = ( " + this.getX() + " ; " + this.getY() + " )" +
                ", initalizationDate = " + this.getInitializationDate() +
                '}';
    }

    public String shortToString() {
        return "Moomin (\'" + this.getName() + "\')" +
                ", position = ( " + this.getX() + " ; " + this.getY() + " )" +
                ", owner = \'" + this.getOwner() + "\'";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Moomin)) return false;
        Moomin moomin = (Moomin) o;
        return this.getCreatureAction().info().equals(moomin.getCreatureAction().info()) &&
                this.getName().equals(moomin.getName()) &&
                this.getSex().toString().equals(moomin.getSex().toString()) &&
                this.getLastCall() == moomin.getLastCall() &&
                this.getLastEnd() == moomin.getLastEnd() &&
                this.getHeight() == moomin.getHeight() &&
                this.getX() == moomin.getX() &&
                this.getY() == moomin.getY() &&
                this.getInitializationDate().equals(moomin.getInitializationDate()) &&
                new Double(moomin.getEnergy()).compareTo(new Double(this.getEnergy())) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), lastCall, lastEnd, energy, getHeight(), getX(), getY(), getInitializationDate());
    }

    public String getClassName(){
        return "Moomin";
    }

    public double getMAX_ENERGY() {
        return MAX_ENERGY;
    }
}
