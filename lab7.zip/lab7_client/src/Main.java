/**
 * Класс, в котором создаётся коллекция и запускается работа с ней.
 * @see Client
 */

public class Main {
    public static void main(String[] args) {
        //LocalDateTime defaulted = LocalDateTime.parse("2018-10-22T20:15:56");
        //System.out.println(defaulted.plusHours(10));
        //Hemul hemul = new Hemul(Sex.MALE, "Man", new CollectRareFlowers(), 50, -9, 10, LocalDateTime.parse("2015-07-18T06:05:04"));
        //Hemul hemulCopy = new Hemul(Sex.MALE, "Man", new CollectRareFlowers(), 50, -9, 10, LocalDateTime.parse("2015-07-18T06:05:04"));
        //System.out.println(hemul.equals(hemulCopy));
        //System.out.println(hemul.hashCode());
        //System.out.println(hemulCopy.hashCode());
        //add_if_min{ "Class" : "Hatifnutt", "Name" : "Mary", "Height" : 192, "X" : -89, "Y" : -77, "Date" : "2018-06-27T05:51:52"}
        //add{"Class" : "Moomin", "Name" : "Ivan", "Sex" : "MALE", "LastCall" : -100, "LastEnd" : 150, "Energy" : -156.98, "Height": 90, "X" : 55, "Y": -40, "Date" : "2015-07-18T06:05:04"}
        //System.out.println("import {dd.csv}".matches("([a-z_]+) (\\{[a-zA-Z0-9_\\.\\-]+)\\}"));

        Client client = new Client();
        client.go(args);

        /*CreatureFactory createMomin = new CreatureFactory("\"Class\" : \"Moomin\", \"Name\" : \"Ivan\", \"Sex\" : \"MALE\", \"LastCall\" : -100, \"LastEnd\" : 150, \"Energy\" : -156.98, \"Height\": 90, \"X\" : 55, \"Y\": -40, \"Date\" : \"2015-07-18T06:05:04\"".replaceAll("\\s+", ""), true);
        CreatureFactory createMomin1 = new CreatureFactory("\"Class\" : \"Moomin\", \"Name\" : \"Ivan\", \"Sex\" : \"MALE\", \"LastCall\" : -100, \"LastEnd\" : 150, \"Energy\" : -156.98, \"Height\": 90, \"X\" : 55, \"Y\": -40, \"Date\" : \"2015-07-18T06:05:04\"".replaceAll("\\s+", ""), true);
        Moomin moomin = (Moomin)createMomin.getValue();
        Moomin moomin1 = (Moomin)createMomin1.getValue();
        System.out.println(moomin.equals(moomin1));
        System.out.println(Double.compare(moomin1.getEnergy(), moomin.getEnergy()));

        System.out.println(moomin1.getCreatureAction().info().equals(moomin.getCreatureAction().info()));
        System.out.println(moomin1.getName().equals(moomin.getName()));
        System.out.println(moomin1.getSex().toString().equals(moomin.getSex().toString()));
        System.out.println(moomin1.getLastCall() == moomin.getLastCall());
        System.out.println(moomin.getLastEnd());
        System.out.println(moomin1.getLastEnd());
        System.out.println(moomin1.getLastEnd() == moomin.getLastEnd());
        System.out.println(moomin1.getHeight() == moomin.getHeight());
        System.out.println(moomin1.getX() == moomin.getX());
        System.out.println(moomin1.getY() == moomin.getY());
        System.out.println(moomin1.getInitializationDate().equals(moomin.getInitializationDate()));
        System.out.println(new Double(moomin.getEnergy()).compareTo(new Double(moomin1.getEnergy())) == 0);
        Moomin moominCopy = new Moomin();
        Hemul hemulCopy = new Hemul();
        Hatifnutt hatifCopy = new Hatifnutt();

        System.out.println(moomin.csvDescription());
        //System.out.println(hemul.csvDescription());
        //System.out.println(hatif.csvDescription());

        System.out.println(moomin.toString());
        //System.out.println(hemul.toString());
        //System.out.println(hatif.toString());

        System.out.println(moomin.equals(moominCopy));
        //System.out.println(hemul.equals(hemulCopy));
        //System.out.println(hatif.equals(hatifCopy));*/
    }
}
