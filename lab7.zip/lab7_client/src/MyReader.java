import java.io.*;
import java.util.Arrays;
import java.util.HashSet;

/**
 * Класс, предназначенный для чтения из файла, хранящего состояние Коллекции между вызовами программы, и дозаписи в него.
 */
public class MyReader {
    /**
     * Переменная с адресом файла, хранящего состояние Коллекции.
     */
    private String address;
    /**
     * Переменная с ссылкой на Коллекцию.
     */
    private HashSet<Creature> objects;
    /**
     * Переменная-флаг, показывающая, существует ли файл, указанный в системной переменной. False - существует, True - не существует.
     * @see MyReader#isFileNotFound()
     */
    private boolean fileNotFound;

    /**
     * Конструктор, принимающий адрес файла, хранящего состояние Коллекции, и ссылку на Коллекцию.
     * @param address адрес файла, хранящего состояние Коллекции между вызовами программы.
     * @param hashSet ссылка на Коллекцию.
     */
    public MyReader(String address, HashSet<Creature> hashSet){
        this.address = address;
        if(address == null)
            fileNotFound = true;
        else
            fileNotFound = false;
        objects = hashSet;
    }

    /**
     * Метод, производящий распаковку объектов из файла.
     * @throws IOException Если с файлом проблемы.
     */
    public void read() throws IOException {
        if(!fileNotFound) {
            try {
                InputStreamReader in = new InputStreamReader(new FileInputStream(address), "UTF-8");
                try {      // блок, создающий коллекцию из файла
                    System.out.format("+ Extraction from %s\n", address);
                    int bufferSize = 130000;
                    char[] buffer = new char[bufferSize];
                    CreatureFactory creator;
                    int readSize = in.read(buffer, 0, buffer.length);
                    if (readSize < bufferSize) {
                        buffer = Arrays.copyOf(buffer, readSize);    // копирование в buffer, если количество считанных символов
                    }                                                 // меньше 1024, т.к. иначе лишние переносы строк
                    for (String st : new String(buffer).split("\n")) {   // деление на строки и создание объектов
                        creator = new CreatureFactory(st, false);
                        if (creator.isCheckFormat()) {
                            objects.add(creator.getValue());
                            System.out.println("... adding: " + creator.getValue().toString());
                        }
                    }
                    System.out.print("+ Extraction is complete.\n-----------------------------------------------------\n\n");
                    copyObjects();
                } catch (UnsupportedEncodingException e) {
                    System.out.println("Кодировка не поддерживается.");
                } catch (NegativeArraySizeException e) {
                    System.out.println("Нет данных в файле.");
                    System.out.print("+ Extraction is complete.\n-----------------------------------------------------\n\n");
                } catch (SecurityException e) {
                    System.out.println("Файл недоступен для чтения.");
                }
            } catch (FileNotFoundException e) {
                System.out.println("Файл не найден.");
            }
        }
        else{
            System.out.println("Файла не существует.");
            System.exit(0);
        }
    }

    /**
     * Метод выводит Коллекцию (HashSet&lt;Creature&gt;) в файл.
     * @throws IOException Если с файлом проблемы.
     */
    public void write() throws IOException{
        this.write(this.address);
    }

    /**
     * Метод выводит Коллекцию (HashSet&lt;Creature&gt;) в файл по указанному адресу.
     * @param address адрес файла для вывода.
     * @throws IOException Если с файлом по указанному адресу проблемы.
     */
    private void write(String address) throws IOException{
        try {
            File f = new File(address);
            f.delete();
            f.createNewFile();
            try (PrintWriter writer = new PrintWriter(f, "UTF-8")) {
                for (Creature creature : objects) {
                    writer.println(creature.csvDescription());
                }
            } catch (FileNotFoundException e) {
                System.out.println("Файл не найден.");
            }
        } catch (SecurityException e){
            System.out.println("Файл недоступен для записи.");
        }
    }

    /**
     * Метод делает "backup" файла с данными о состоянии Коллекции. "Backup"-файл имеет постфикс "_last_copy" и лежит в той же директории, что и сам файл с данными о Коллекции.
     * @throws IOException Если с файлом проблемы.
     */
    private void copyObjects() throws IOException {
        this.write(address.substring(0, address.length() - 4) + "_last_copy.csv");
    }

    /**
     * Метод-"геттер" для поля fileNotFound.
     * @see MyReader#fileNotFound
     * @return Возвращает значение поля fileNotFound.
     */
    public boolean isFileNotFound() {
        return fileNotFound;
    }
}
