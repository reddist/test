import java.io.IOException;

public class ChangeLab4 {
    public static void main(String[] args) {
        try {
            //Runtime.getRuntime().exec("del C:/Users/VN7-592G-53XM/Desktop/Labs/2_semester/Programming/lab7/lab7_client/src/Lab4/*.class");
            Runtime.getRuntime().exec("javac -d C:/Users/VN7-592G-53XM/Desktop/Labs/2_semester/Programming/lab7/lab7_client/src/Lab4 C:/Users/VN7-592G-53XM/Desktop/Labs/2_semester/Programming/lab7/lab7_client/src/Lab4/*.java");
            Runtime.getRuntime().exec("jar -cvf lab4.jar -d C:/Users/VN7-592G-53XM/Desktop/Labs/2_semester/Programming/lab7/lab7_client/src/Lab4/ C:/Users/VN7-592G-53XM/Desktop/Labs/2_semester/Programming/lab7/lab7_client/src/Lab4/*.class");
            //Runtime.getRuntime().exec("replace " +
                    //"C:/Users/VN7-592G-53XM/Desktop/Labs/2_semester/Programming/lab7/lab7_client/src/Lab4/lab4.jar" +
                    //"C:/Users/VN7-592G-53XM/Desktop/Labs/2_semester/Programming/lab7/lab7_client/src/");
        } catch (IOException e){
            e.printStackTrace();
        }
    }
}
