import java.io.IOException;
import java.util.HashSet;
import java.util.stream.Collectors;

/**
 * Класс, предназначенный для выполнения команд, содержит реализации всех доступных в интерактивном режиме команд программы.
 */
public class CommandExecutor {
    /**
     * Коллекция, с которой производятся действия.
     */
    private HashSet<Creature> hashSet;

    /**
     * Переменная, обозначающая тип выхода из программы. True - выход с помощью команды CommandExecutor.abort(), False - выход с помощью команды CommandExecutor.exit(MyReader).
     * @see CommandExecutor#exit(MyReader)
     * @see CommandExecutor#abort()
     */
    private static boolean isAbort = false;

    /**
     * Конструктор, принимающий ссылку на Коллекцию.
     * @param objects Коллекция типа HashSet&lt;Creature&gt;
     */
    public CommandExecutor(HashSet<Creature> objects){
        this.hashSet = objects;
    }

    /**
     * Добавляет элемент в коллекцию.
     * @param creature объект
     * @return Возвращает True, если элемент добавлен, False - если нет.
     */
    public boolean add(Creature creature){
        return hashSet.add(creature);
    }

    /**
     * Добавляет элемент в коллекцию, если его значение меньше, чем у наименьшего элемента этой коллекции.
     * @param creature объект
     * @return Возвращает True, если элемент добавлен, False - если нет.
     */
    public boolean add_if_min(Creature creature){
        long count = this.hashSet.stream()
                                    .filter(cr -> (creature.getName().length() >= cr.getName().length()))       // оставляет те элементы, длина имени которых <= длине имени переданного
                                    .count();
        if(count > 0)
            return false;
        else
            return hashSet.add(creature);
        /*for(Creature cr : hashSet) {
            if (creature.getName().length() >= cr.getName().length()) {
                return false;
            }
        }
        return hashSet.add(creature);*/
    }

    /**
     * Удаляет элемент из коллекции.
     * @param creature объект
     * @return Возвращает True, если элемент удалён, False - если нет.
     */
    public boolean remove(Creature creature){
        return hashSet.remove(creature);
    }

    /**
     * Удаляет из коллекции все элементы, превышающие заданный.
     * @param creature объект
     * @return Возвращает строку с именами удалённых объектов или 'Nothing'.
     */
    public String remove_greater(Creature creature){
        String returned = "";
        HashSet<Creature> copyOfHashSet = new HashSet<Creature>();
        HashSet<Creature> changeableCopyOfHashSet = new HashSet<Creature>();
        int numberOfDeletedElemets = 0;
        copyOfHashSet.addAll(hashSet);
        changeableCopyOfHashSet.addAll(hashSet);
        StringBuffer returnBuilder = new StringBuffer();
        changeableCopyOfHashSet = new HashSet<Creature>(
                                            changeableCopyOfHashSet.stream()
                                                    .filter(cr -> cr.getName().length() <= creature.getName().length())     // оставляет элементы с длиной имени <= длины имени переданного
                                                    .collect(Collectors.toSet())
                                        );
        numberOfDeletedElemets = copyOfHashSet.size() - changeableCopyOfHashSet.size();
        copyOfHashSet.stream()
                            .filter(cr -> cr.getName().length() > creature.getName().length())
                            .forEach(cr -> returnBuilder.append(cr.getName() + " (" + cr.getClassName() + ")" + "; "));
        /*for(Creature cr : hashSet) {
            if (creature.getName().length() < cr.getName().length()) {
                numberOfDeletedElemets += 1;
                returned += cr.getName() + " (" + cr.getClassName() + ")" + "; ";
                changeableCopyOfHashSet.remove(cr);
            }
        }*/
        if(numberOfDeletedElemets == 0) {
            return "Nothing";
        } else {
            hashSet.removeAll(copyOfHashSet);
            hashSet.addAll(changeableCopyOfHashSet);
            returned = returnBuilder.toString();
            return returned;
        }
    }

    /**
     * Удаляет из коллекции все элементы, меньшие, чем заданный.
     * @param creature объект
     * @return Возвращает строку с именами удалённых объектов или 'Nothing'.
     */
    public String remove_lower(Creature creature){
        String returned = "";
        HashSet<Creature> copyOfHashSet = new HashSet<Creature>();
        HashSet<Creature> changeableCopyOfHashSet = new HashSet<Creature>();
        int numberOfDeletedElemets = 0;
        copyOfHashSet.addAll(hashSet);
        changeableCopyOfHashSet.addAll(hashSet);
        StringBuffer returnBuilder = new StringBuffer();
        changeableCopyOfHashSet = new HashSet<Creature>(
                changeableCopyOfHashSet.stream()
                        .filter(cr -> cr.getName().length() >= creature.getName().length())     // оставляет элементы с длиной имени >= длины имени переданного
                        .collect(Collectors.toSet())
        );
        numberOfDeletedElemets = copyOfHashSet.size() - changeableCopyOfHashSet.size();
        copyOfHashSet.stream()
                .filter(cr -> cr.getName().length() < creature.getName().length())
                .forEach(cr -> returnBuilder.append(cr.getName() + " (" + cr.getClassName() + ")" + "; "));
        /*for(Creature cr : hashSet) {
            if (creature.getName().length() > cr.getName().length()) {
                returned += cr.getName() + " (" + cr.getClassName() + ")" + "; ";
                numberOfDeletedElemets += 1;
                changeableCopyOfHashSet.remove(cr);
            }
        }*/
        if(numberOfDeletedElemets == 0) {
            return "Nothing";
        } else {
            hashSet.removeAll(copyOfHashSet);
            hashSet.addAll(changeableCopyOfHashSet);
            returned = returnBuilder.toString();
            return returned;
        }
    }


    /**
     * Выводит в стандартный поток вывода все элементы коллекции в строковом представлении.
     */
    public void show(){
        hashSet.stream()
                    .forEach(creature -> System.out.println("\t" + creature.toString() + ", hashCode = " + creature.hashCode()));
        /*for (Creature creature : hashSet) {
            System.out.println("\t" + creature.toString() + ", hashCode = " + creature.hashCode());
        }*/
    }


    /**
     * Выводит в стандартный поток вывода информацию о коллекции (тип, количество элементов, дата инициализации).
     */
    public void info(){
        System.out.println("\tТип коллекции - Creature\n" + "\tРазмер коллекции - " + hashSet.size() + " элементов");
        //System.out.println("\tДата инициализации - " + Client.getInitializationDate());
    }

    /**
     * Выводит информацию о всех доступных командах, их Формате и Формате json-объектов, используемых в командах.
     */
    public void help(){
        System.out.println("Допустимые команды: ");
            System.out.println("\thelp - Выводит информацию о доступных командах и формате json-объектов, используемых в командах.");
            System.out.println("\tinfo - Выводит в стандартный поток вывода информацию о коллекции (тип, количество элементов, дата инициализации).");
            System.out.println("\tshow - Выводит в стандартный поток вывода все элементы коллекции в строковом представлении (в том числе hashCode каждого элемента).");
            System.out.println("\texit - Сохраняет данные и выполняет выход из программы.");
            System.out.println("\tabort - Выполняет выход из программы (!) без сохранения данных.");
            System.out.println("\tsave - Сохраняет данные.");
            System.out.println("\tadd {element}: - Добавляет новый элемент в коллекцию.");
            System.out.println("\tremove {element} - Удаляет элемент из коллекции по его значению.");
            System.out.println("\tremove_greater {element} - Удаляет из коллекции все элементы, превышающие заданный.");
            System.out.println("\tremove_lower {element} - Удаляет из коллекции все элементы, меньшие, чем заданный.");
            System.out.println("\tadd_if_min {element} - Добавляет новый элемент в коллекцию, если его значение меньше, чем у наименьшего элемента этой коллекции.\n");
        System.out.println("Формат json-объектов {element}:");
            System.out.println("\t1) Объект обязан иметь поля \"Class\" и \"Name\". Поле \"Class\" может иметь значения \"Hatifnutt\", ");
                System.out.println("\t\t\"Moomin\" или \"Hemul\". \u0418мя объекта (поле \"Name\") может состоять из букв и цифр. ");
                System.out.println("\t\tТакже поля \"Class\" и \"Name\" - необходимые и достаточные для объекта класса \"Hatifnutt\".");
            System.out.println("\t2) Для объекта класса \"Hemul\", помимо \"Class\" и \"Name\", необходимы следующие поля: ");
                System.out.println("\t\t\"Sex\" - пол объекта. Может принимать значения \"MALE\"; \"FEMALE\"; \"AGAMIC\" (бесполый).");
                System.out.println("\t\t\"Vocation\" - занятие объекта. Может принимать значения \"CollectThings\"; \"CollectRareFlowers\"; \"Ski\".");
            System.out.println("\t3) Для объекта класса \"Moomin\", помимо \"Class\" и \"Name\", необходимы следующие поля: ");
                System.out.println("\t\t\"Sex\" - пол объекта. Может принимать значения \"MALE\"; \"FEMALE\"; \"AGAMIC\" (бесполый).");
                System.out.println("\t\t\"LastCall\" - Последнее время, когда объект начал что-то делать. Может принимать значения [ " + Integer.MIN_VALUE + " ; " + Integer.MAX_VALUE + " ] (тип int).");
                System.out.println("\t\t\"LastEnd\" - Последнее время, когда объект закончил что-то делать. Может принимать значения [ " + Integer.MIN_VALUE + " ; " + Integer.MAX_VALUE + " ] (тип int).");
                System.out.println("\t\t\"Energy\" - текущая энергия объекта. Может принимать значения [ " + Double.MIN_VALUE + " ; " + Double.MAX_VALUE + " ] (тип double).");
    }

    /**
     * Метод производит сохранение Коллекции в файл, хранящий состояние Коллекции между запусками программы.
     * @param reader "считыватель" из первоначального класса.
     * @see MyReader#write()
     */
    public void save(MyReader reader){
        System.out.println(">>> Сохранение данных в файл...");
        try {
            reader.write();
        } catch (IOException e){
            System.out.println(">>> С файлом что-то не так.");
        }
        System.out.println(">>> Заверешено.");

    }

    /**
     * Метод производит выход из программы, при этом состояние Коллекции сохраняется, с помощью CommandExecutor.save(MyReader).
     * @param reader "считыватель" из первоначального класса.
     * @see CommandExecutor#save(MyReader)
     */
    public void exit(MyReader reader){
        setAbort(false);
        System.exit(0);
    }

    /**
     * Метод производит выход из программы, (!) при этом состояние Коллекции НЕ сохраняется.
     * @see CommandExecutor#save(MyReader)
     * @see CommandExecutor#exit(MyReader)
     */
    public void abort(){
        setAbort(true);
        System.exit(0);
    }

    /**
     * Метод устанавливает значение статического поля isAbort.
     * @param abort Устанавливаемое значение.
     * @see CommandExecutor#isAbort
     */
    private static void setAbort(boolean abort) {
        isAbort = abort;
    }

    /**
     * Метод - 'геттер' для статического поля CommandExecutor.isAbort.
     * @return Значение статического поля CommandExecutor.isAbort.
     * @see CommandExecutor#isAbort
     */
    public static boolean getIsAbort() {
        return isAbort;
    }
}
