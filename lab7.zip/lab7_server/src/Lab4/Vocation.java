package Lab4;

import java.io.Serializable;

public interface Vocation extends Serializable {
	void do_(Object o) throws IncorrectVocationParameter;
	String getCurrentVocation();
	String info();
	String getCorrectParameter();
}