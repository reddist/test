package Lab4;

import java.io.Serializable;

public enum Condition implements Serializable {
	NORMAL,
	BROKEN,
	INDESTRUCTIBLE;

	@Override
	public String toString(){
		String st = "";
		switch(this){
			case NORMAL: st = "Normal";
				break;
			case BROKEN: st = "Broken";
				break;
			case INDESTRUCTIBLE: st = "Indestuctible";
				break;
		}
		return st;
	}
}