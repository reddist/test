package Lab4;

import java.io.Serializable;

public interface CreatureAction extends Serializable{
	 void walk();
	 void eat(Thing th);
	 void communicate(Creature cr, String phrase);
	 String info();
}