package Lab4;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static java.lang.Math.*;

public class Ski implements Vocation, Serializable {

    private SlatPair slatPair;

    public Ski() {
        this(new SlatPair("Mighty Eagle", "Angry", "Fast"));
        //slats = new ArrayList<Slat>();
        //slats.add(new Slat("Left slat"));
        //slats.add(new Slat("Right slat"));
    }

    public Ski(SlatPair s) {
        slatPair = s;
    }

    public void do_(Object o) throws IncorrectVocationParameter{
        if(!(o instanceof SlatPair) && !(o instanceof Integer)) throw new IncorrectVocationParameter(this.getCorrectParameter());
        if(!(o instanceof Integer)) this.changeSlatPair((SlatPair) o);
        if (slatPair.getCondition().equals(Condition.NORMAL)) {
            System.out.println("slides down the snow mountain.");
            slatPair.breaks();
        } else {
            System.out.println("is unable to ski. Slat pair is broken. Trying to repair...");
            slatPair.repair();
        }
    }

    public String getCurrentVocation() {
        return "Ski";
    }

    public String getCorrectParameter(){
        return "SlatPair, int";
    }

    public SlatPair getSlatPair() {
        return slatPair;
    }

    public void changeSlatPair(SlatPair slatPair) {
        this.slatPair = slatPair;
    }

    private void changeRightSlat(String name, Condition cond){
        slatPair.changeSlat(name, cond, "right");
    }

    private void changeLeftSlat(String name, Condition cond){
        slatPair.changeSlat(name, cond, "left");
    }

    public String info() {
        String s = "Condition of slat pair: ";
        s += slatPair.getLeftSlat().getName() + "(left) - " + slatPair.getLeftSlat().getCondition().toString() + ", ";
        s += slatPair.getRightSlat().getName() + "(right) - " + slatPair.getRightSlat().getCondition().toString() + ".";
        return s;
    }

    @Override
    public String toString(){
        return getCurrentVocation();
    }


}
