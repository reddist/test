package Lab4;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Hatifnutt extends Creature implements Serializable {
	
	public Hatifnutt(){
		this("Hatifnutt");
	}
	
	public Hatifnutt(String name){
		this(name, 50, 20, 20, LocalDateTime.parse("2018-10-22T20:15:56"));
		this.setCreatureAction(new HatifnuttAction());
		this.setName(name);
		this.setSex(Sex.AGAMIC);
	}

	public Hatifnutt(String name, int height, int posX, int posY, LocalDateTime date){
		this.setCreatureAction(new HatifnuttAction());
		this.setName(name);
		this.setSex(Sex.AGAMIC);
		this.setHeight(height);
		this.setX(posX);
		this.setY(posY);
		this.setInitializationDate(date);
	}

	@Override
	public void eat(Thing th){
		this.bow(th);
		super.eat(th);
	}

	
	public void bow(Thing th){
		System.out.println(this.getName() + " bows to the " + th.getName().toLowerCase() + ".");
	}

	public void bow(Barometer b){
		System.out.println(this.getName() + " bows to the " + b.getName().toLowerCase() + ".");
		b.addBow();
	}

	@Override
	public String toString() {
		return "Hatifnutt{" +
				"creatureAction = " + this.getCreatureAction().info() +
				", name = '" + this.getName() + '\'' +
				", sex = " + this.getSex() +
				", height = " + this.getHeight() +
				", position = ( " + this.getX() + " ; " + this.getY() + " )" +
				", initalizationDate = " + this.getInitializationDate() +
				'}';
	}

	public String shortToString() {
		return "Hatifnutt (\'" + this.getName() + "\')" +
				", position = ( " + this.getX() + " ; " + this.getY() + " )" +
				", owner = \'" + this.getOwner() + "\'";
	}

	class Barometer extends Thing{
		private int amountOfBows;

		public Barometer(){
			super("Barometer", Condition.INDESTRUCTIBLE);
		}
		public void addBow() {
			this.setAmount(amountOfBows + 1);
		}

		public int getAmount(){
			return this.amountOfBows;
		}
		public void setAmount(int a){
			this.amountOfBows = a;
		}

		@Override
		public String toString(){
			return "Barometer{amount of bows = " + amountOfBows + '}';
		}

	}

	public String csvDescription(){
		return "Hatifnutt, " + this.getName() + ", " + this.getHeight()
				+ ", " + this.getX() + ", " + this.getY()
				+ ", " + this.getInitializationDate()
				+ ", " + this.getOwner();
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object o) {
		return super.equals(o);
	}

	public String getClassName(){
		return "Hatifnutt";
	}
}