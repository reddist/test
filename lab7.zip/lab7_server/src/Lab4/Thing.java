package Lab4;

import java.io.Serializable;
import java.util.Objects;

public abstract class Thing implements Serializable {
	private String nameOfThing;
	private Condition condition;

	/*public Thing(){
		this("Abstract thing", Condition.INDESTRUCTIBLE);
	}*/
	public Thing(String name){
		this(name, Condition.NORMAL);
	}
	public Thing(String name, Condition c){
		this.setName(name);
		this.setCondition(c);
	}

	public void breaks(){
		if(this.condition.equals(Condition.NORMAL) == true){
			this.condition = Condition.BROKEN;
			System.out.println(this.getName() + " becomes broken.");
		}else
			if(this.condition.equals(Condition.INDESTRUCTIBLE) == true){
				System.out.println(this.getName() + " is indestructible.");
			}else System.out.println(this.getName() + " is already broken.");
	}
	public void setCondition(Condition cond){
		this.condition = cond;
	}
	public Condition getCondition(){
		return this.condition;
	}
	public void setName(String name){
		this.nameOfThing = name;
	}
	public String getName(){
		return this.nameOfThing;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Thing)) return false;
		Thing thing = (Thing) o;
		return Objects.equals(nameOfThing, thing.nameOfThing) &&
				condition == thing.condition;
	}

	@Override
	public int hashCode() {
		return Objects.hash(nameOfThing, condition);
	}

	/*@Override
	public String toString() {
		return "Thing{" +
				"nameOfThing = '" + nameOfThing + '\'' +
				", condition = " + condition +
				'}';
	}*/
}