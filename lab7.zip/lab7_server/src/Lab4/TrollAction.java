package Lab4;

import java.io.Serializable;

public class TrollAction extends HemulAction implements Serializable{

    private double energy;          // energy in joules
    private long time;            // time in milliseconds
    private static final TrollAction jump;
    private static final TrollAction maneuver;
    private static final TrollAction makeHearth;
    private static final TrollAction heating;

    public TrollAction(){
        this(0, 0);
    }

    private TrollAction(double energy, double time){
        this.setEnergy(energy);
        this.time = (long)time;
    }

    public void walk() {
        System.out.println(" goes.");
    }

    public String info() {
        return "Troll Action";
    }

    public void do_(Object o) throws NotFoodException {
        System.out.println(" exists.");
    }

    private void setEnergy(double p){
        energy = p;
    }

    public double getEnergy(){
        return energy;
    }
    public long getTime(){
        return this.time;
    }

    public static TrollAction getJump() {
        return TrollAction.jump;
    }

    public static TrollAction getManeuver() {
        return maneuver;
    }

    public static TrollAction getMakeHearth() {
        return makeHearth;
    }

    public static TrollAction getHeating() {
        return heating;
    }

    static{
        jump = new TrollAction(50.5, 1500.0){
            @Override
            public String info() {
                return "jumping";
            }

            public void do_(Object o){
                System.out.println(" jumps with a rope.");
            }
        };
        maneuver = new TrollAction(70.36, 5000.0){
            @Override
            public String info() {
                return "maneuvering";
            }

            public void do_(Object o){
                System.out.println(" is maneuvering through the shallows to get to the coast.");
            }
        };
        makeHearth = new TrollAction(265.87, 10000.0){
            @Override
            public String info() {
                return "making a hearth";
            }

            public void do_(Object o){
                System.out.println(" is making a hearth.");
            }
        };
        heating = new TrollAction(40.54, 4000.0){
            @Override
            public String info() {
                return "heating";
            }

            public void do_(Object o) throws NotFoodException{
                String message = " is heating " + o.toString() + ". It's temperature condition will be ";
                if (!(o instanceof Food))
                    throw new NotFoodException(" is unable to heat " + o);
                else {
                    ((Food) o).getHeated();
                    message += ((Food) o).getTemperatureCondition() + ".";
                    System.out.println(message);
                }
            }
        };
    }
}
