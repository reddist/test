package Lab4;

import java.io.Serializable;

public class IncorrectVocationParameter extends RuntimeException implements Serializable {
    public IncorrectVocationParameter(String type){
        super("Wrong vocation parameter type. Expected type \'" + type + "\'.");
    }
}
