package Lab4;

import java.io.Serializable;

public class Food extends Thing implements Serializable {

    private TemperatureCondition temperatureCondition;
    private double energyValue;

    public Food(String name){
        this(name, TemperatureCondition.NORMAL, 1.5);
    }

    public Food(String name, TemperatureCondition cond, double enV){
        super(name);
        temperatureCondition = cond;
        energyValue = enV;
    }

    public void info(){
        System.out.println(this.getName() + " has temperature: " + temperatureCondition.toString() + ";   "
                + "Energy value is " + this.getEnergyValue() + " kilo-joules");
    }

    public double getEnergyValue() {
        return energyValue;
    }

    public void getHeated(){
        switch(temperatureCondition){
            case COLD: temperatureCondition = TemperatureCondition.NORMAL;
                break;
            case NORMAL: temperatureCondition = TemperatureCondition.WARM;
                break;
            case WARM: {
                temperatureCondition = TemperatureCondition.BURNED;
                if(this.getCondition().equals(Condition.NORMAL))
                    this.setCondition(Condition.BROKEN);
            } break;
        }
    }

    public TemperatureCondition getTemperatureCondition() {
        return temperatureCondition;
    }

    @Override
    public String toString() {
        return "Food{" +
                "name = " + this.getName() +
                ", condition = " + this.getCondition() +
                ", temperatureCondition = " + temperatureCondition +
                ", energyValue = " + energyValue +
                '}';
    }
}
