package Lab4;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

public class Hemul extends Creature implements Serializable {
	private Vocation vocation;
	private Object parameter;
	
	public Hemul(){
		this(Sex.MALE, "Hemul", new CollectThings(), new RareFlower(), 50, 20, 20, LocalDateTime.parse("2018-10-22T20:15:56"));
	}

	public Hemul(Sex sex, String name){
		this(sex, name, new CollectThings(), new Hatifnutt().new Barometer(), 50, 20, 20, LocalDateTime.parse("2018-10-22T20:15:56"));
	}

	public Hemul(Sex sex, String name, Vocation v, int height, int posX, int posY, LocalDateTime date){
		this(sex, name, v, null, height, posX, posY, date);
	}

	private Hemul(Sex sex, String name, Vocation v, Object p, int height, int posX, int posY, LocalDateTime date){
		this.setCreatureAction(new HemulAction());
		this.setName(name);
		this.setVocation(v);
		this.setSex(sex);
		this.setParameter(p);
		this.setHeight(height);
		this.setX(posX);
		this.setY(posY);
		this.setInitializationDate(date);
	}
	
	public void do_(){
		try {
			do_(this.getParameter());
		}catch(NullPointerException e){
			System.out.println("Hemul has no Parameter.");
		}
	}

	public void do_(Object o){
		//try {
			System.out.print(this.getName() + " ");
			this.getVocation().do_(o);
		//}catch(IncorrectVocationParameter i){
			//System.out.println("Hemul has the wrong Parameter for vocation. Expected type \'" +
					//this.getVocation().getCorrectParameter() + "\'.");
			//System.out.println(i.getMessage());
		//}
	}

	@Override
	public void walk(){
		super.walk();
		System.out.print(Sex.toAdj(this.getSex()) + " favorite avocation, ");
		System.out.println(this.vocation.getCurrentVocation() + ".");
	}


	public Vocation getVocation(){
		return this.vocation;
	}
	public void setVocation(Vocation v){
		this.vocation = v;
	}

	public Object getParameter() {
		return parameter;
	}
	public void setParameter(Object parameter) {
		this.parameter = parameter;
	}

	public String csvDescription(){
		return "Hemul, " + this.getSex().toString().toUpperCase() + ", " + this.getName()
				+ ", " + this.getVocation().getCurrentVocation()
				+ ", " + this.getHeight() + ", " + this.getX() + ", " + this.getY()
				+ ", " + this.getInitializationDate()
				+ ", " + this.getOwner();
	}

	@Override
	public String toString() {
		return "Hemul{" +
				"creatureAction = " + this.getCreatureAction().info() +
				", name = \'" + this.getName() + '\'' +
				", sex = " + this.getSex() +
				", vocation = " + vocation.getCurrentVocation() +
				", parameter = " + parameter +
				", height = " + this.getHeight() +
				", position = ( " + this.getX() + " ; " + this.getY() + " )" +
				", initalizationDate = " + this.getInitializationDate() +
				'}';
	}

	public String shortToString() {
		return "Hemul (\'" + this.getName() + "\')" +
				", position = ( " + this.getX() + " ; " + this.getY() + " )" +
				", owner = \'" + this.getOwner() + "\'";
	}



	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Hemul)) return false;
		Hemul hemul = (Hemul) o;
		return Objects.equals(this.getName(), hemul.getName()) &&
				this.getSex() == hemul.getSex() &&
				this.getHeight() == hemul.getHeight() &&
				this.getX() == hemul.getX() &&
				this.getY() == hemul.getY() &&
				this.getInitializationDate().equals(hemul.getInitializationDate()) &&
				Objects.equals(this.getVocation().getCurrentVocation(), hemul.getVocation().getCurrentVocation());
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	public String getClassName(){
		return "Hemul";
	}
}