package Lab4;

import java.io.Serializable;

public enum Sex implements Serializable {
	MALE,
	FEMALE,
	AGAMIC;
	
	public static String toAdj(Sex s){
		String adjective;
		switch(s){
			case MALE: adjective = "his";
					   break;
			case FEMALE: adjective = "her";
						 break;
			default: adjective = "its";
						 break;
		}
		return adjective;
	}

	@Override
	public String toString(){
		String st = "";
		switch(this){
			case MALE: st = "Male";
				break;
			case FEMALE: st = "Female";
				break;
			case AGAMIC: st = "Agamic";
				break;
		}
		return st;
	}
}
