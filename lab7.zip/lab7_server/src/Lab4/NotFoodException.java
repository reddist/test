package Lab4;

import java.io.Serializable;

public class NotFoodException extends Exception implements Serializable {
    public NotFoodException(String message){
        super(message);
    }
}

