package Lab4;

import java.io.Serializable;
import java.util.*;

public class RareFlower extends Thing implements Serializable {
	private RareFeature rareFeature;
	public RareFlower(){
		super("Flower");
           this.setFeature(RareFeature.randomRareFeature());
		   if(this.getFeature().equals(RareFeature.TWO_PART_TWILIGHT))
			   this.setName(rareFeature.toString() + " flower");
		   else
			   this.setName("Flower with " + rareFeature.toString().toLowerCase());
	}
	private void setFeature(RareFeature feat){
           this.rareFeature = feat;
	}
	public RareFeature getFeature(){
		return this.rareFeature;
	}
	// toString () : String
	// equals () : boolean
	// hashCode () : int

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof RareFlower)) return false;
		if (!super.equals(o)) return false;
		RareFlower that = (RareFlower) o;
		return rareFeature == that.rareFeature;
	}

	@Override
	public int hashCode() {
		return Objects.hash(super.hashCode(), rareFeature);
	}

	@Override
	public String toString() {
		return "RareFlower{" +
				"rareFeature=" + rareFeature +
				'}';
	}

	enum RareFeature{
		TWO_PART_TWILIGHT,
		SILVER_WHIGHT_INFLORESCENCES,
		RED_AND_BLACK_COROLLAS;

		private static final List<RareFeature> VALUES = Collections.unmodifiableList(Arrays.asList(values()));
		private static final int SIZE = VALUES.size();

		public static RareFeature randomRareFeature(){
			return VALUES.get(new Random().nextInt(SIZE));
		}

		public String toString(){
			String st = "";
			switch(this){
				case TWO_PART_TWILIGHT: st = "Two-part twilight";
					break;
				case SILVER_WHIGHT_INFLORESCENCES: st = "Silwer-whight inflorescences";
					break;
				case RED_AND_BLACK_COROLLAS: st = "Red and black corollas";
					break;
			}
			return st;
		}
	}
}

